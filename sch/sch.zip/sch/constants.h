#pragma once

// Define schedule type enum:
//	RR = 1
//	DRR = 2
enum sch_type { UNINITIALIZED, RR_TYPE, DRR_TYPE};

#define MAX_FLOWS_NUM 32000
#define MAX_IP_LENGTH 15 